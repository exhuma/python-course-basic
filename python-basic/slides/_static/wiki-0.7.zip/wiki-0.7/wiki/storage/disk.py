from os import listdir
from os.path import join, exists
import json

from wiki.model import WikiPage


class DiskStorage:

    def __init__(self, root):
        self.root = root

    def init(self):
        pass

    def close(self):
        pass

    def save(self, document):
        filename = join(self.root,
                        document.title) + '.json'
        with open(filename, 'w') as file_hndl:
            json.dump({
                'title': document.title,
                'content': document.content
            }, file_hndl)

    def load(self, title):
        filename = join(self.root,
                        title) + '.json'
        if not exists(filename):
            return None

        with open(filename, 'r') as file_handle:
            document = json.load(file_handle)

        return WikiPage(document['title'],
                        document['content'])

    def list(self):
        titles = []
        for filename in listdir(self.root):
            title, _ = filename.rsplit('.', 1)
            titles.append(title)
        return titles
