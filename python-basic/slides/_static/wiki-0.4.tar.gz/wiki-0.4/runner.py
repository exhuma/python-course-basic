from wiki.model import WikiPage
from wiki.storage.disk import (
    DiskStorage
)

storage = DiskStorage('wiki_pages')
for page in storage.list():
    print(page)

mypage = WikiPage('HelloWorld', 'This is an example!')
storage.save(mypage)

for page in storage.list():
    print(page)

loaded_page = storage.load('HelloWorld')
print(mypage == loaded_page)
