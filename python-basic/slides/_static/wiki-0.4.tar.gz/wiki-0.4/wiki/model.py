class WikiPage:

    def __init__(self, title, content):
        self.title = title
        self.content = content

    def teaser(self):
        return self.content
