from flask import Flask, g, render_template
from wiki.storage.disk import DiskStorage


APP = Flask(__name__)


@APP.before_request
def before_request():
    g.db = DiskStorage('wiki_pages')


@APP.route('/')
def index():
    return 'Hello World'


@APP.route('/list')
def list():
    page_names = g.db.list()
    return render_template('pagelist.html',
                           page_names=page_names)


@APP.route('/<name>')
def display(name):
    page = g.db.load(name)
    return render_template('page.html', page=page)

if __name__ == '__main__':
    APP.run(debug=True, host='0.0.0.0',
            port=5000)
