import sqlite3

from wiki.model import WikiPage


class SQLiteStorage:

    def __init__(self, dsn):
        self.connection = sqlite3.connect(dsn)

    def init(self):
        cursor = self.connection.cursor()
        cursor.execute(
            '''
            CREATE TABLE wikipage (
                title TEXT NOT NULL PRIMARY KEY,
                content TEXT);
            ''')

        cursor.close()
        self.connection.commit()

    def close(self):
        self.connection.close()

    def save(self, document):
        cursor = self.connection.cursor()
        cursor.execute('SELECT COUNT(*) FROM wikipage '
                       'WHERE title=?',
                       [document.title])
        existing = cursor.fetchone()
        if existing[0] > 0:
            cursor.execute('UPDATE wikipage SET content=? '
                           'WHERE title=?',
                           [document.content, document.title])
        else:
            cursor.execute('INSERT INTO wikipage '
                           '(title, content) VALUES (?, ?)',
                           [document.title, document.content])
        cursor.close()
        self.connection.commit()

    def load(self, title):
        cursor = self.connection.cursor()
        cursor.execute('SELECT title, content FROM wikipage '
                       'WHERE title=?',
                       [title])
        row = cursor.fetchone()
        cursor.close()
        if not row:
            return None
        else:
            title, content = row
            return WikiPage(title, content)

    def list(self):
        cursor = self.connection.cursor()
        cursor.execute('SELECT title FROM wikipage')

        titles = []
        for row in cursor:
            titles.append(row[0])
        cursor.close()
        return titles
