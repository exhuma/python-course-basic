from setuptools import setup, find_packages
setup(
    name='wiki',
    description="Replacement for Wikipedia",
    url="http://www.newwp-project.com",
    license="BSD",
    author="Michel Albert",
    author_email="michel@albert.lu",
    version='1.0',
    packages=find_packages(),
    install_requires=[
        'Flask',
    ],
)
