import re

from flask import Flask, g, render_template, redirect, url_for, request

from wiki.model import WikiPage


APP = Flask(__name__)
P_WIKIWORD = re.compile(r'\b((?:[A-Z][a-z0-9]+){2,})\b')


@APP.template_filter('wikify')
def wikify(text):
    return text


@APP.before_first_request
def init_storage():
    pass


@APP.before_request
def before_request():
    pass


@APP.teardown_request
def teardown_request(request):
    return request


@APP.route('/')
def index():
    pass


@APP.route('/list')
def list():
    pass


@APP.route('/<name>')
def display(name):
    pass


@APP.route('/', methods=['POST'])
def save_page():
    pass


if __name__ == '__main__':
    APP.run(debug=True, host='0.0.0.0', port=5000)
