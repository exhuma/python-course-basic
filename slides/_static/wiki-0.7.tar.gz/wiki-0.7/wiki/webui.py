import re

from flask import Flask, g, render_template, redirect, url_for, request

from wiki.model import WikiPage
from wiki.storage.sqlite import SQLiteStorage


APP = Flask(__name__)
P_WIKIWORD = re.compile(r'\b((?:[A-Z][a-z0-9]+){2,})\b')


def make_page_url(match):
    groups = match.groups()
    title = groups[0]
    return '<a href="{url}">{title}</a>'.format(
        url=url_for('display', name=title),
        title=title)


@APP.template_filter('wikify')
def wikify(text):
    # NOTE: We could do much more here!
    return P_WIKIWORD.sub(make_page_url, text)


@APP.before_first_request
def init_storage():
    try:
        db = SQLiteStorage('wikipages.sqlite')
        db.init()
    except Exception as exc:
        print(exc)
    finally:
        db.close()


@APP.before_request
def before_request():
    g.db = SQLiteStorage('wikipages.sqlite')


@APP.teardown_request
def teardown_request(request):
    g.db.close()
    return request


@APP.route('/')
def index():
    return redirect('/Index')


@APP.route('/list')
def list():
    page_names = g.db.list()
    return render_template('pagelist.html',
                           page_names=page_names)


@APP.route('/<name>')
def display(name):
    page = g.db.load(name)
    if not page:
        return render_template('edit_page.html', name=name)
    if 'edit' in request.args:
        return render_template('edit_page.html', name=name,
                               content=page.content)
    return render_template('page.html', page=page)


@APP.route('/', methods=['POST'])
def save_page():
    page = WikiPage(request.form['title'],
                    request.form['content'])
    g.db.save(page)
    return redirect(url_for('display', name=page.title))


if __name__ == '__main__':
    APP.run(debug=True, host='0.0.0.0',
            port=5000)
