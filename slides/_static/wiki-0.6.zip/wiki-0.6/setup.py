from setuptools import setup, find_packages
setup(
    name='wiki',
    description="Replacement for Wikipedia",
    url="http://www.newp-project.com",
    license="BSD",
    author="Michel Albert",
    author_email="michel@albert.lu",
    version='0.6',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'Flask',
    ],
)
